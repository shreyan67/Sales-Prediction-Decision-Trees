# Import necessary libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt


file_path = r'C:\Users\HP\OneDrive\Desktop\M project\train.csv' 
data = pd.read_csv(file_path)


data['date'] = pd.to_datetime(data['date'])
data['year'] = data['date'].dt.year
data['month'] = data['date'].dt.month
data['day'] = data['date'].dt.day
data.drop(columns=['date'], inplace=True)


X = data[['store', 'item', 'year', 'month', 'day']]
y = data['sales']


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


model = DecisionTreeRegressor(random_state=42)
model.fit(X_train, y_train)


mse = mean_squared_error(y_test, model.predict(X_test))
r2 = r2_score(y_test, model.predict(X_test))
print(f"Model Evaluation:\nMean Squared Error (MSE): {mse:.2f}\nR² Score: {r2:.2f}")


print("\nEnter the date to predict sales (YYYY-MM-DD):")
input_date = input("Date: ").strip()


try:
    input_date = pd.to_datetime(input_date)
    year, month, day = input_date.year, input_date.month, input_date.day
except Exception as e:
    print(f"Error: {e}. Please provide a valid date in YYYY-MM-DD format.")
    exit()


prediction_data = pd.DataFrame({
    'store': data['store'].unique().repeat(len(data['item'].unique())),
    'item': list(data['item'].unique()) * len(data['store'].unique()),
    'year': year,
    'month': month,
    'day': day
})


prediction_data['predicted_sales'] = model.predict(prediction_data)

print("\nPredicted Sales:")
print(prediction_data)


plt.figure(figsize=(10, 6))
for store_id in prediction_data['store'].unique():
    store_data = prediction_data[prediction_data['store'] == store_id]
    plt.plot(store_data['item'], store_data['predicted_sales'], label=f"Store {store_id}")

plt.title(f"Predicted Sales on {input_date.date()}")
plt.xlabel("Item ID")
plt.ylabel("Predicted Sales")
plt.legend()
plt.grid()
plt.show()
